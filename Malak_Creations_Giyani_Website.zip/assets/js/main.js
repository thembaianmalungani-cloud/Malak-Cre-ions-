const BUSINESS_WHATSAPP = "27800000000"; // Replace with Malak Cre@ions' confirmed WhatsApp number.
const bookingMessage = encodeURIComponent("Ahee 👋 I would like to book an appointment with Malak Cre@ions. Please share your available times and services.");
const waUrl = `https://wa.me/${BUSINESS_WHATSAPP}?text=${bookingMessage}`;

["whatsappBtn","contactWhatsapp","floatingWhatsapp"].forEach(id=>{
  const el=document.getElementById(id);
  if(el) el.href=waUrl;
});
document.getElementById("year").textContent=new Date().getFullYear();

const toggle=document.querySelector(".menu-toggle");
const nav=document.querySelector(".nav");
toggle?.addEventListener("click",()=>{
  const open=nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded",open);
});
document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));

document.querySelectorAll('a[href^="#"]').forEach(link=>{
  link.addEventListener("click",e=>{
    const target=document.querySelector(link.getAttribute("href"));
    if(target){
      e.preventDefault();
      target.scrollIntoView({behavior:"smooth",block:"start"});
    }
  });
});

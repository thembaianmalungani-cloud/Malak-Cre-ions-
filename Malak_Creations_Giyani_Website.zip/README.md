# Malak Cre@ions Website

A polished, responsive website preview for Malak Cre@ions in Giyani.

## Included
- Responsive homepage
- About section
- Services
- Gallery
- FAQ
- WhatsApp booking CTA
- Contact/location section
- SEO metadata
- Mobile navigation
- Editable WhatsApp number

## Important
Before delivering to the client, replace the placeholder WhatsApp number in:

`assets/js/main.js`

with Malak Cre@ions' confirmed WhatsApp number.

Also replace/adjust any business-specific details once the client confirms them.

## Run
Open `index.html` in a browser, or upload the complete folder to your hosting account.
